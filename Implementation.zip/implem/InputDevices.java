import java.util.Scanner;
public class InputDevices extends HardwareDevices {
    private String model;
    public InputDevices(){
        super();
    }
    public InputDevices(String name,int price,int qty,String model){
        super(name,price,qty);
        this.model=model;
    }
    public void setmodel(String model){
        this.model=model;
    }
    public  int getmodel(){
        return model;
    }
    public String toString(){
        return (super.toString());
    }  
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        InputDevices id = new InputDevices();
        System.out.println("Enter device name\t");
        id.setname(input.nextLine());
        System.out.println("Enter device price\t");
        id.setprice(input.nextInt());
        System.out.println("Enter number of device\t");
        id.setquantity(input.nextInt());
        System.out.println("Enter model for mouse\t");
        id.setmodel(input.nextLine());
        System.out.println(id.toString());
    }  
}

import java.util.Scanner;
public class OutputDevices extends HardwareDevices{
    private int size;
    private String resol;
    public OutputDevices(){
        super();
    }
    public OutputDevices(String name,int price,int qty,int size,String resol){
        super(name,price,qty);
        this.size=size;
        this.resol=resol;
    }
    public void setsize(int size){
        this.size=size;
    }
    public  int getsize(){
        return size;
    }
    public void setresolution(String resol){
        this.resol=resol;
    }
    public  String getresolution(){
        return resol;
    }
    public String toString(){
        return (super.toString());
    }   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        OutputDevices od = new OutputDevices();
        System.out.println("Enter Device name\t");
        od.setname(input.nextLine());
        System.out.println("Enter device price\t");
        od.setprice(input.nextInt());
        System.out.println("Enter number of device\t");
        od.setquantity(input.nextInt());
        System.out.println("Enter device size\t");
        od.setsize(input.nextInt());
        System.out.println("Enter device resolution if it's screen\t");
        od.setresolution(input.nextLine());
        System.out.println(od.toString());
    }
}

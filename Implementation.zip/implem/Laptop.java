import java.util.Scanner;
public class Laptop extends HardwareDevices {
    private double Storage;
    private double processor;
    private double memory;
    public Laptop(){
        super();
    }
    public Laptop(String name,int price,int qty,double Storage,double processor,double memory){
        super(name,price,qty);
        this.Storage=Storage;
        this.processor=processor;
        this.memory=memory;
    }
    public void setStorage(double Storage){
        this.Storage=Storage;
    }
    public  double getStorage(){
        return Storage;
    }
    public void setProc(double processor){
        this.processor=processor;
    }
    public  double getProc(){
        return processor;
    }
    public void setMem(double memory){
        this.memory=memory;
    }
    public  double getMem(){
        return memory;
    }
    public String toString(){
        return (super.toString());
    }     
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Laptop lap = new Laptop();
        System.out.println("Enter laptop name\t");
        lap.setname(input.nextLine());
        System.out.println("Enter laptop price\t");
        lap.setprice(input.nextInt());
        System.out.println("Enter laptop number\t");
        lap.setquantity(input.nextInt());
        System.out.println("Enter storage size\t");
        lap.setStorage(input.nextDouble());
        System.out.println("Enter processor size\t");
        lap.setProc(input.nextDouble());
        System.out.println("Enter memory size\t");
        lap.setMem(input.nextDouble());
        System.out.println(lap.toString());
    }  
}

public class HardwareDevices {
    private String name;
    private int price;
    private int qty;
    public HardwareDevices(){

    }
    public HardwareDevices(String name,int price,int qty){
        this.name=name;
        this.price=price;
        this.qty=qty;
    }
    public void setname(String name){
        this.name=name;
    }
    public String getname(){
        return name;
    }
    public void setprice(int price){
        this.price=price;
        if(price<=0){
            this.price=price;
        }
        else{
            System.out.println("Invalid input");
        }
    }
    public  int getprice(){
        return price;
    }
    public void setquantity(int qty){
        this.qty=qty;
        if(qty<=0){
            this.qty=qty;
        }
        else{
            System.out.println("Invalid input");
        }
    }
    public  int getquantity(){
        return qty;
    }
    public String toString(){
        return "Amount to pay\t"+qty*price;
    }

}

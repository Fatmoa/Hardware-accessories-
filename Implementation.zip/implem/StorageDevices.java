import java.util.Scanner;
public class StorageDevices extends HardwareDevices {
    private int size;
    public StorageDevices(){
        super();
    }
    public StorageDevices(String name,int price,int qty,int size){
        super(name,price,qty);
        this.size=size;
    }
    public void setsize(int size){
        this.size=size;
    }
    public  int getsize(){
        return size;
    }
    public String toString(){
        return (super.toString()+size);
    }    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        StorageDevices sd = new StorageDevices();
        System.out.println("Enter device name\t");
        sd.setname(input.nextLine());
        System.out.println("Enter device price\t");
        sd.setprice(input.nextInt());
        System.out.println("Enter number of device\t");
        sd.setquantity(input.nextInt());
        System.out.println("Enter device size\t");
        sd.setsize(input.nextInt());
        System.out.println(sd.toString());
    }
}
